import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-navigation-bar',
  templateUrl: './admin-navigation-bar.component.html',
  styleUrls: ['./admin-navigation-bar.component.css']
})
export class AdminNavigationBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
